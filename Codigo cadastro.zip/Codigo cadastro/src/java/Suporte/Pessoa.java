package Suporte;

public class Pessoa {
    
    String html = "";
    
    public Pessoa(){
        html += "<select name=\"Pessoa\" id=\"Pessoa\">";
        html += "<option value=\"Física\">Física</option>";
        html += "<option value=\"Jurídica\">Jurídica</option>";
        html += "</select>";
    }
    
    public String getPessoa(){
        return html;
    }
    
}
