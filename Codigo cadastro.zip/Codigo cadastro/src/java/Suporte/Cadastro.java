package Suporte;

public class Cadastro {
    
    private int CPF;
    private String Nome;
    private String Pessoa;
    private float Senha;
    private float Confirmarsenha;
    private String obs;
    private String acao;

    public int getCPF() {
        return CPF;
    }

    public void setCPF(int CPF) {
        this.CPF = CPF;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getPessoa() {
        return Pessoa;
    }

    public void setPessoa(String Pessoa) {
        this.Pessoa = Pessoa;
    }

    public float getSenha() {
        return Senha;
    }

    public void setSenha(float Senha) {
        this.Senha = Senha;
    }

    public float getConfirmarsenha() {
        return Confirmarsenha;
    }

    public void setConfirmarsenha(float Confirmarsenha) {
        this.Confirmarsenha = Confirmarsenha;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public String getAcao() {
        return acao;
    }

    public void setAcao(String acao) {
        this.acao = acao;
    }
    
    
}
